from django.apps import AppConfig


class ESurveyAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'e_survey_app'
