from django.contrib import admin
from .models import YourModel
admin.site.register(YourModel)