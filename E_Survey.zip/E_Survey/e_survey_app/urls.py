from django.urls import path
from .views import signup, login_view, logout_view,fhome, home, survey_create,survey_types,customersurvey,websitefeedback,navbar,secondnavbar
urlpatterns = [
    path('login/', login_view, name='login'),
    path('home/', home, name='home'),
    path('fhome/', fhome, name='fhome'),
    path('',navbar,name='navbar'),
    path('signup/', signup, name='signup'),
    path('logout/', logout_view, name='logout'),

    # path('/home', home, name='home'),
    path('survey_create/', survey_create, name='survey_create'),
    path('survey-types/', survey_types, name='survey_types'),
    path('customersurvey/', customersurvey, name='customersurvey'),
    path('websitefeedback/', websitefeedback, name='websitefeedback'),

]
